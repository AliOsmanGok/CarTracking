//
//  UserSettings.swift
//  CarTracking
//
//  Created by Ali Osman GÖK on 6.09.2023.
//

import Foundation
import SwiftUI

class UserSettings: ObservableObject{
    @Published var isLoggedIn : Bool{
        didSet{
            UserDefaults.standard.set(isLoggedIn, forKey: "login")
        }
    }
    init(){
        self.isLoggedIn = false
    }
}

