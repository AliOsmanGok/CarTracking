//
//  ViewsModel.swift
//  CarTracking
//
//  Created by Ali Osman GÖK on 6.09.2023.
//

import Foundation
import FirebaseStorage

class ViewModels : ObservableObject {
    @Published var imageURL : URL?
    
    func getURL(path: String) {
        let storage = Storage.storage()
        storage.reference().child(path).downloadURL(completion: { url, error in
            guard let url = url, error == nil else {
                return
            }
            self.imageURL = url
        })
    }
}

