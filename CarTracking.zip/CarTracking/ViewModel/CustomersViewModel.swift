//
//  CustomersViewModel.swift
//  CarTracking
//
//  Created by Ali Osman GÖK on 6.09.2023.
//


import Foundation
import Combine
import FirebaseFirestore
 
class CustomersViewModel: ObservableObject {
  @Published var customers = [Customer]()
   
  private var db = Firestore.firestore()
  private var listenerRegistration: ListenerRegistration?
   
  deinit {
    unsubscribe()
  }
   
  func unsubscribe() {
    if listenerRegistration != nil {
      listenerRegistration?.remove()
      listenerRegistration = nil
    }
  }
   
  func subscribe() {
    if listenerRegistration == nil {
        listenerRegistration = db.collection("customers").order(by: "name").addSnapshotListener { (querySnapshot, error) in
        guard let documents = querySnapshot?.documents else {
          print("No documents")
          return
        }
         
        self.customers = documents.compactMap { queryDocumentSnapshot in
          try? queryDocumentSnapshot.data(as: Customer.self)
        }
      }
    }
  }
   
  func removeCustomers(atOffsets indexSet: IndexSet) {
    let customers = indexSet.lazy.map { self.customers[$0] }
    customers.forEach { customer in
      if let documentId = customer.id {
        db.collection("customers").document(documentId).delete { error in
          if let error = error {
            print("Unable to remove document: \(error.localizedDescription)")
          }
        }
      }
    }
  }
 
   
}


