//
//  ContentView.swift
//  CarTracking
//
//  Created by Ali Osman GÖK on 6.09.2023.
//

import SwiftUI
import Firebase

 
struct ContentView: View {
  
    
    @State var search = ""
    @ObservedObject var data = getData()
    @StateObject var viewModel = CustomersViewModel()
    @State var presentAddCustomerSheet = false
    @EnvironmentObject var settings: UserSettings
    @State var sorgu = false
    
    
    private var addButton: some View {
      Button(action: { self.presentAddCustomerSheet.toggle() }) {
        Image(systemName: "plus")
      }
    }
     
    private func customerRowView(customer: Customer) -> some View {
      NavigationLink(destination: CustomerDetailsView(customer: customer)) {
        VStack(alignment: .leading) {
            HStack {
                //AnimatedImage(url: URL(string: customer.image)!).resizable().frame(width: 65, height: 65).clipShape(Circle())
                 
                VStack(alignment: .leading) {
                    LabeledContent {
                        if customer.kalan != ""{
                            Text("\(customer.kalan) ₺")
                                .foregroundColor(Color.red)
                        }
                    } label: {
                        Text(customer.name)
                        Text(customer.plaka)
                    }
                }
            }
        }


      }    }
     
    var body: some View {
       
        NavigationView {
            VStack{

                List {
                    ForEach (viewModel.customers.filter{(self.search.isEmpty ? true : $0.name.localizedCaseInsensitiveContains(self.search))}) { customer in
                        customerRowView(customer: customer)
                    }
                    .onDelete() { indexSet in
                        viewModel.removeCustomers(atOffsets: indexSet)
                    }
                }
                .searchable(text: self.$search)
                    .toolbar {
                        ToolbarItem(placement: .navigationBarLeading) {
                            Button("\(Image(systemName: "door.right.hand.open"))") {
                                settings.isLoggedIn = false
                            }
                        }
                    }
                    .navigationBarTitle("Müşteriler")
                    .navigationBarItems(trailing: addButton)
                    .onAppear() {
                        print("CustomersListView appears. Subscribing to data updates.")
                        self.viewModel.subscribe()
                    }
                    .sheet(isPresented: self.$presentAddCustomerSheet) {
                        CustomerEditView()
                    }
                    
              /*  Button("< Araç Sorgulama"){
                    self.sorgu.toggle()
                }
                .fullScreenCover(isPresented:$sorgu){
                    inView()
                }*/
            }


        }
        
    }
  }
 
struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
