//
//  inView.swift
//  CarTracking
//
//  Created by Ali Osman GÖK on 6.09.2023.
//

import SwiftUI

struct inView: View {
    @State var customers = false
    @State var admin = false
    
    var body: some View {
        NavigationView{
            VStack{

                Button{
                    self.admin.toggle()
                }label: {
                    Text("Şirket İsmi").font(.headline)
                        
                }
                .fullScreenCover(isPresented: $admin){
                    LoginView()
                }
                
                Image("logo")
                    .resizable()
                    .frame(width: UIScreen.main.bounds.width * 0.85, height: UIScreen.main.bounds.height * 0.25)
                    .cornerRadius(10)
                    .overlay(RoundedRectangle(cornerRadius: 10)
                        .stroke(Color.black, lineWidth: 5))
                    .shadow(radius: 10)
                    .padding()
                Button("Araç Sorgulama >"){
                    self.customers.toggle()
                }
                .padding()
                .foregroundColor(Color.white)
                .font(.title2)
                .background(Color.blue)
                .clipShape(Capsule())
                .fullScreenCover(isPresented: $customers){
                    CustomerView()
                }
            }
            .offset(y: UIScreen.main.bounds.height * -0.15)
        }
    }
}

struct inView_Previews: PreviewProvider {
    static var previews: some View {
        inView()
    }
}
