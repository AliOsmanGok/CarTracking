//
//  CustomerView.swift
//  CarTracking
//
//  Created by Ali Osman GÖK on 6.09.2023.
//

import SwiftUI

struct CustomerView: View {
    @State var search = ""
    @ObservedObject var data = getData()
    @StateObject var viewModel = CustomersViewModel()
    @State var presentAddCustomerSheet = false
    @EnvironmentObject var settings: UserSettings
    @State var backs = false
    
    private func customerRowView(customer: Customer) -> some View {
      NavigationLink(destination: Customers(customer: customer)) {
        VStack(alignment: .leading) {
            HStack {
                //AnimatedImage(url: URL(string: customer.image)!).resizable().frame(width: 65, height: 65).clipShape(Circle())
                 
                VStack(alignment: .leading) {
                    Text("\(customer.sifre)")
                }
            }
        }
      }
    }
    var body: some View {
     
            NavigationView {
                ZStack{

                    
                    List{
                        
                        
                        ForEach (viewModel.customers.filter{
                            (self.search == $0.sifre)
                            
                        }) { customer in
                            customerRowView(customer: customer)
                            
                        }
                    }
                    .searchable(text: self.$search, prompt: "Şifre giriniz...")
                    .onAppear{
                        viewModel.subscribe()
                    }
                    HStack{

                        Button {
                            self.backs.toggle()
                        } label: {
                            Text("< Anasayfa").foregroundColor(.gray)
                        }.fullScreenCover(isPresented: $backs){
                            inView()
                        }

                         
                            
                    }.offset(y: UIScreen.main.bounds.height * 0.4)
                }
            }
            .navigationTitle("Şirket İsmi")
            
        
    }
}

struct CustomerView_Previews: PreviewProvider {
    static var previews: some View {
        CustomerView()
    }
}

struct Customers: View{
    @Environment(\.presentationMode) var presentationMode
    @State var presentEditCustomerSheet = false
      var customer: Customer
     @ObservedObject var viewModel = CustomerViewModel()
    var body: some View{
        List{
            Section(header: Text("Tarih")){
                Text("Tarih: \(customer.tarih)").font(.footnote)
            }
            Section(header: Text("Araç Bilgileri")){
                Text("Plaka: \(customer.plaka)")
                Text("Marka Model: \(customer.marka)")
                Text("Kilometre: \(customer.km)")
                if customer.nextKm != "" {
                    Text("Bir sonraki değişim kilometresi: \(customer.nextKm)")
                }
            }
            Section(header: Text("Yapılan işlemler")){
                if customer.islem != ""{
                    Text("\(customer.islem)")
                }
                if customer.oil != ""{
                    Text("Yağ: \(customer.oil)")
                }
                if customer.havaF != ""{
                    Text("Hava Filtresi değişti.")
                }
                if customer.yagF != ""{
                    Text("Yağ Filtresi değişti.")
                }
                if customer.yakıtF != ""{
                    Text("Yakıt Filtresi değişti.")
                }
                if customer.polenF != ""{
                    Text("Polen Filtresi değişti.")
                }
                Group{
                    
                if customer.antifriz != ""{
                    Text("Antifiriz değişti.")
                }
                    
                if customer.fren != ""{
                    Text("Fren Balatası değişti.")
                }
                    
                if customer.debriyaj != ""{
                    Text("Debriyaj Seti değişti.")
                }
                    
                if customer.vKayiş != ""{
                    Text("V Kayışı değişti.")
                }
             
                if customer.triger != ""{
                    Text("Triger Kayışı değişti.")
                }
                    
                if customer.buji != ""{
                    Text("Buji değişti.")
                }
                    
                if customer.nots != ""{
                    Text("Not: \(customer.nots)")
                }
                    
                }
                
            }
            
        }.navigationTitle("Şirket İsmi").font(.callout)
           
    }
}
