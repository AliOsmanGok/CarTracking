//
//  CustomerDetailsView.swift
//  CarTracking
//
//  Created by Ali Osman GÖK on 6.09.2023.
//


import SwiftUI
import SDWebImageSwiftUI
import FirebaseAuth
import FirebaseStorage
 
@MainActor
struct CustomerDetailsView: View {
    @State var imageURL = ""
    @StateObject private var viewModel = ViewModels()
   @State var kart = false
  @Environment(\.presentationMode) var presentationMode
  @State var presentEditCustomerSheet = false
    var customer: Customer
    @State var image: UIImage?
    @State private var text = "Your text here"
    @State private var renderedImage = Image(systemName: "photo")
    @Environment(\.displayScale) var displayScale
   

   
  private func editButton(action: @escaping () -> Void) -> some View {
    Button(action: { action() }) {
      Text("Düzenle")
    }
  }

    var body: some View {
        VStack{

            Section{
                List{
                    Group{
                        Section(header: Text("müşteri bilgileri")){
                            if customer.name != ""{
                                LabeledContent {
                                    Text(customer.tarih)
                                    
                                } label: {
                                    Text(customer.name)
                                    
                                }
                            }
                            if customer.telefon != ""{
                                Text("Telefon : \(customer.telefon)")
                            }
                            if customer.plaka != ""{
                                Text("Araç Plakası : \(customer.plaka)")
                            }
                            if customer.sifre != ""{
                                Text("Şifre : \(customer.sifre)")
                            }
                            if customer.marka != ""{
                                Text("Marka Model : \(customer.marka)")
                            }
                            if customer.sikayet != ""{
                                Text("Müşteri Şikayeti : \(customer.sikayet)")
                            }
                            if customer.km != ""{
                                Text("Kilometre : \(customer.km)")
                            }
                            if customer.şase != ""{
                                Text("Şase No : \(customer.şase)")
                            }
                            if customer.not != ""{
                                Text("Not : \(customer.not)")
                            }
                        }
                        if customer.islem != "" {
                            Section(header: Text("İşlem Bilgileri")){
                                if customer.isyeri != ""{
                                    Text("İşyeri Notu: \(customer.isyeri)")
                                }
                                if customer.islem != ""{
                                    Text("Yapılan İşlemler : \(customer.islem)")
                                }
                            }
                        }
                    }
                    Group{
                        if customer.toplam != "" {
                            Section(header: Text("Cari Bilgiler")){
                                if customer.yedekp != ""{
                                    Text("Yedek Parça: \(customer.yedekp) ₺")
                                }
                                if customer.iscilik != ""{
                                    Text("İşçilik : \(customer.iscilik) ₺")
                                }
                                if customer.yag != ""{
                                    Text("Yağ: \(customer.yag) ₺")
                                }
                                if customer.disIsler != ""{
                                    Text("Dış İşler: \(customer.disIsler) ₺")
                                }
                                if customer.sarf != "" {
                                    Text("Sarf Malzeme: \(customer.sarf)")
                                }
                                if customer.toplam != ""{
                                    Text("Toplam: \(customer.toplam) ₺")
                                }
                                if customer.alınan != ""{
                                    Text("Ödenen: \(customer.alınan) ₺")
                                }
                                if customer.kalan != ""{
                                    Text("Kalan: \(customer.kalan) ₺")
                                }
                            }
                        }

                        
                        if customer.oil != "" {
                            Section(header: Text("Bakım Bilgileri")){
                                
                                
                                
                                if customer.oil != ""{
                                    Text("Tarih: \(customer.tarih)")
                                    Text("Kilometre: \(customer.km)")
                                    Text("Sonraki Değişim Kilometresi: \(customer.nextKm)")
                                    Text("Yağ: \(customer.oil)")
                                }
                                if customer.havaF != ""{
                                    Text("Hava Filtresi değişti.")
                                }
                                if customer.yagF != ""{
                                    Text("Yağ Filtresi değişti.")
                                }
                                if customer.yakıtF != ""{
                                    Text("Yakıt Filtresi değişti.")
                                }
                                if customer.polenF != ""{
                                    Text("Polen Filtresi değişti.")
                                }
                                Group{
                                    if customer.antifriz != ""{
                                        Text("Antifiriz değişti.")
                                    }
                                    if customer.fren != ""{
                                        Text("Fren Balatası değişti.")
                                    }
                                    if customer.debriyaj != ""{
                                        Text("Debriyaj Seti değişti.")
                                    }
                                    if customer.vKayiş != ""{
                                        Text("V Kayışı değişti.")
                                    }
                                    
                                    if customer.triger != ""{
                                        Text("Triger Kayışı değişti.")
                                    }
                                    if customer.buji != ""{
                                        Text("Buji değişti.")
                                    }
                                    if customer.nots != ""{
                                        Text("Not: \(customer.nots)")
                                    }
                                }
                                
                                
                            }
                        }
                    }
                    
                          /*sd Section(header: Text("Resim")){
                      
                                  /*/ AnimatedImage(url: URL(string: "https://firebasestorage.googleapis.com/v0/b/selimcar.appspot.com/o/\(customer.resim)?alt=media&token=3bde8001-639a-4295-87f2-49e66bc49a7b")!).resizable().frame(width: 300, height: 300)*/
                               
                               if let url = viewModel.imageURL {
                                   AnimatedImage(url: url).resizable().frame(width:400, height: 500)
                                }

                            
                               
                           }*/
                       
                    Group{
                      /*  Button("Servis Kartı"){
                            self.kart.toggle()
                        }.sheet(isPresented:$kart){
                            Detail(customer: customer)
                        }*/
                        ShareLink("Bakım Kartı", item: renderedImage, preview: SharePreview(Text("\(customer.plaka)"), image: renderedImage)).foregroundColor(.red)
                            

               

                    }
                        
                    ShareLink("Servis Formu", item: render()).foregroundColor(.red)
                      
                }        .onChange(of: text) { _ in renders() }
                    .onAppear { renders() }
            }

        }
        .onAppear {
            viewModel.getURL(path: "\(customer.resim)")
                }
        .navigationBarTitle(customer.name)
        .navigationBarItems(trailing: editButton {
            self.presentEditCustomerSheet.toggle()
        })
        .onAppear() {
            print("CustomerDetailsView.onAppear() for \(self.customer.name)")
        }
        .onDisappear() {
            print("CustomerDetailsView.onDisappear()")
        }
        .sheet(isPresented: self.$presentEditCustomerSheet) {
            CustomerEditView(viewModel: CustomerViewModel(customer: customer), mode: .edit) { result in
                if case .success(let action) = result, action == .delete {
                    self.presentationMode.wrappedValue.dismiss()
                }
            }
        }
    //  Text("───────────────────────────────────")
  }
    func loadImageFromFirebase() {
    
        let storage = Storage.storage().reference(withPath: "\(fileName).jpeg")
        storage.downloadURL { (url, error) in
            if error != nil {
                //print((error?.localizedDescription)!)
                return
            }
            //print(url!)
            self.imageURL = "\(url!)"
            //print("Yükleme adresiniz \(url!)")
            storage.downloadURL { url, error in
                print("Yükleme adresiniz \(imageURL)")
            }
            

        

        }
    }
    func render() -> URL {

     
        let renderer = ImageRenderer(content: formView(customer: customer))

        let url = URL.documentsDirectory.appending(path: "\(customer.name).pdf")


        renderer.render { size, context in
    
            var box = CGRect(x: 0, y: 0, width: 595, height: 842)

       
            guard let pdf = CGContext(url as CFURL, mediaBox: &box, nil) else {
                return
            }

           
            pdf.beginPDFPage(nil)

    
            context(pdf)


            pdf.endPDFPage()
            pdf.closePDF()
        }

        return url
    }
    
    @MainActor func renders() {
        let renderer = ImageRenderer(content: RenderView(text: "", customer: customer))
        
        
        renderer.scale = displayScale
        _ = UIImage(named: "\(customer.plaka)")


     
 
        if let uiImage = renderer.uiImage {
            renderedImage = Image(uiImage: uiImage)
            
        }
    }
   
    
    
}

struct formView: View{
    @Environment(\.presentationMode) var presentationMode
    @State var presentEditCustomerSheet = false
      var customer: Customer
     @ObservedObject var viewModel = CustomerViewModel()
    var box = CGRect(x: 0, y: 0, width: 595, height: 842)

    var body: some View {
        ZStack(alignment: .topLeading){
                 VStack{

                     HStack{
                         Image("logo").resizable().frame(width: 200, height: 150)
                             .cornerRadius(10)
                             .padding(10)
                         Spacer()
                         VStack(alignment: .trailing){
                         
                             Text("\(customer.tarih)  ")
                             Text("ŞİRKET İSMİ  ").bold()
                             Text("İSİM SOYİSİM  ")
                             Text("adres...  ").foregroundColor(.gray)
                             Text("adress...  ").foregroundColor(.gray)
                             
                                 HStack{
                                     Image("insta").resizable().frame(width: 15, height: 15)
                                     Text("instagram adresi  ").font(.system(size: 14)).foregroundColor(.gray)
                                 }
                                 HStack{
                                     Image("telephone").resizable().frame(width: 15, height: 15)
                                     Text("telefon numarası ").font(.system(size: 14)).foregroundColor(.gray)
                                 }
                             

                         }.offset(y: box.height * 0.015)
                        
                     }
                     VStack{
                         Text("SERVİS FORMU")
                         Text("───────────────────────────────────")
                     }
                     VStack(alignment: .leading){
                         Group{
                             Text(" Müşteri Bilgileri;")
                             Text(" İsim Soyisim  : \(customer.name)")
                             Text(" Telefon           : \(customer.telefon)")
                             Text("───────────────────────────────────")
                         }
                         Group{
                             Text(" Araç Bilgileri;")
                             Text(" Marka Model  : \(customer.marka) ")
                             Text(" Plaka               : \(customer.plaka)")
                             Text(" Kilometre        : \(customer.km)")
                             Text(" Şase No          : \(customer.şase)")
                             
                             Text("───────────────────────────────────")
                         }
                         Group{
                             HStack(alignment: .top){
                                 Text(" Yapılan İşlemler; ")
                       
                             }
      
                         }
                         
                     }
                     
                     
                 }.offset(y: box.height * -0.44)
            let islem = customer.islem
            Text("\(islem)").offset(x: box.width * 0.02 ,y: box.height * 0.12)
                
          

             }

    }
}

struct RenderView: View {
    let text: String
    @Environment(\.presentationMode) var presentationMode
    @State var presentEditCustomerSheet = false
      var customer: Customer
     @ObservedObject var viewModel = CustomerViewModel()


    var body: some View {
        VStack{
          
             
                Image("logo").resizable().frame(width: 220, height: 150)
                    .cornerRadius(10)
                    .overlay(RoundedRectangle(cornerRadius: 10)
                        .stroke(Color.gray, lineWidth: 2))
                    .shadow(radius: 10)
                    .padding(15)
            VStack{
                VStack(alignment: .leading){
                    Text("Tarih: \(customer.tarih)").padding(1)
                    if customer.km != "" {
                        Text("KM: \(customer.km)").padding(1)
                    }
                    if customer.nextKm != "" {
                        Text("Bir Sonraki Değ.KM: \(customer.nextKm)").padding(1)
                    }
                    
                    Group{
                        if customer.oil != "" {
                            Text("Yağ: \(customer.oil) ").padding(1)
                        }
                        if customer.havaF != "" {
                            Text("Hava Filtresi Değişti").padding(1)
                        }
                        if customer.yagF != "" {
                            Text("Yağ Filtresi Değişti").padding(1)
                        }
                        if customer.yakıtF != "" {
                            Text("Yakıt Filtresi Değişti").padding(1)
                        }
                        if customer.polenF != "" {
                            Text("Polen Filtresi Değişti").padding(1)
                        }
                    }
                    Group{
                        if customer.antifriz != "" {
                            Text("Antifiriz Değişti").padding(1)
                        }
                        if customer.fren != "" {
                            Text("Fren Balatası Değişti").padding(1)
                        }
                        if customer.debriyaj != "" {
                            Text("Debriyaj Seti Değişti").padding(1)
                        }
                        if customer.vKayiş != "" {
                            Text("V Kayışı Değişti").padding(1)
                        }
                        if customer.triger != "" {
                            Text("Triger Kayışı Değişti").padding(1)
                        }
                        if customer.buji != "" {
                            Text("Buji Değişti").padding(1)
                        }
                        Text("─────────────────")
                        if customer.nots != "" {
                            Text("Not: \(customer.nots)").padding(1)
                        }
                    }
                }.foregroundColor(.gray).font(.footnote)
                VStack(alignment: .center){
                    Text("Hayırlı yolculuklar dileriz ...").foregroundColor(.gray)
                        .padding(5)
                    
                }
            }
            
        
        }
            
            .overlay(Rectangle()
            .stroke(Color.black, lineWidth: 5))
            .foregroundColor(.white)
         
            .padding(5)
    }
}

struct Loader: UIViewRepresentable{
    
    func makeUIView(context: UIViewRepresentableContext<Loader>) -> UIActivityIndicatorView{
        let indicator = UIActivityIndicatorView(style: .medium)
        indicator.startAnimating()
        return indicator
        
    }
    
    func updateUIView(_ uiView: UIActivityIndicatorView, context: UIViewRepresentableContext<Loader>) {
        //
    }
}
 
struct CustomerDetailsView_Previews: PreviewProvider {
  static var previews: some View {
   
      let customer = Customer(name: "", telefon: "", marka: "", plaka: "", şase: "", sikayet: "", km: "", islem: "", isyeri: "", not: "", resim: "", yedekp: "", iscilik: "", yag: "", disIsler: "", toplam: "", alınan: "", kalan:"" , tarih: "", nextKm:"" , oil: "",
                              havaF: "", yagF:"", yakıtF: "", polenF: "", antifriz: "", fren: "", debriyaj: "",vKayiş: "",triger: "",buji: "", nots: "", sifre: "", sarf: "", resim2: "", resim3: "", resim4: "", resim5: "" )
    return
      NavigationView {
        CustomerDetailsView(customer: customer)
      }
  }
}
