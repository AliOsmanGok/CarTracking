//
//  CustomerEditView.swift
//  CarTracking
//
//  Created by Ali Osman GÖK on 6.09.2023.
//

import SwiftUI
import Firebase
import FirebaseFirestore
import FirebaseStorage
import FirebaseCore
import FirebaseAuth
import SDWebImageSwiftUI

 

var resims = resimad
var resimad = "\(fileName).jpeg"
var fileName = UUID().uuidString
var resim2 = UUID().uuidString
var resim3 = UUID().uuidString
var resim4 = UUID().uuidString
var resim5 = UUID().uuidString



enum Mode {
  case new
  case edit
}
 
enum Action {
  case delete
  case done
  case cancel
}

 
struct CustomerEditView: View {
    


    
 
    @State var shown = false
    @State var shownb = false
    @State var showni = false
    @State var shownü = false
    @State var shownd = false
    @State var imageURL = ""
    @State var imageURLb = ""
    @State var imageURLi = ""
    @State var imageURLü = ""
    @State var imageURLd = ""
    @State var showActionSheet = false
    @State var showImagePicker = false
      

      
    @State var upload_image:UIImage?
    @State var download_image:UIImage?

    @State private var showsAlert = false
       
   
    @Environment(\.presentationMode)  var presentationMode
    @State var presentActionSheet = false
    @State var butonaTiklandi = false
    @State var image: UIImage!
    @State var resim : String = ""
 
  
    
   
  @ObservedObject var viewModel = CustomerViewModel()

  
  var mode: Mode = .new
  var completionHandler: ((Result<Action, Error>) -> Void)?
   
   
  var cancelButton: some View {
    Button(action: { self.handleCancelTapped() }) {
      Text("Geri")
    }
  }
   
  var saveButton: some View {
    Button(action: {
        self.handleDoneTapped()

    }) {
        
        
      Text(mode == .new ? "Kaydet" : "Kaydet")
        
    }
    .disabled(!viewModel.modified)
  }
   
   
  var body: some View {
 
      
      NavigationView {
          
          VStack{
          Form{
              
              Section(header: Text("müşteri kaydı")) {
                  
                  
                  TextField("Ad Soyad", text: $viewModel.customer.name)
                  TextField("Telefon", text: $viewModel.customer.telefon)
                 // TextField("Şifre", text: $viewModel.customer.sifre)
                  TextField("Marka Model", text: $viewModel.customer.marka)
                  TextField("Araç Plakası", text: $viewModel.customer.plaka)
                  TextField("Müşteri Şikayeti", text: $viewModel.customer.sikayet)
                  TextField("Kilometre", text: $viewModel.customer.km)
                  TextField("Şase Numarası", text: $viewModel.customer.şase)
                  
                  TextField("Not", text: $viewModel.customer.not)
                  TextField("Tarih", text: $viewModel.customer.tarih)
              }
              Section(header: Text("İşlem Kaydı")){
                      TextField(text: $viewModel.customer.islem, prompt: Text("Yapılan İşlemler"), axis: .vertical) {
                          Text("islem")
                      }
                      TextField("İşyeri Notu", text: $viewModel.customer.isyeri)
                  }
              
              Section(header: Text("Cari Kayıt")){
                  let yedek = Int(viewModel.customer.yedekp) ?? 0
                  let isci = Int(viewModel.customer.iscilik) ?? 0
                  let yağ = Int(viewModel.customer.yag) ?? 0
                  let dış = Int(viewModel.customer.disIsler) ?? 0
                  let sarf = Int(viewModel.customer.sarf) ?? 0
                  let toplams = yedek + isci + yağ + dış + sarf
                  
                  TextField("Yedek Parça", text: $viewModel.customer.yedekp)
                  TextField("İşçilik", text: $viewModel.customer.iscilik)
                  TextField("Yağ", text: $viewModel.customer.yag)
                  TextField("Dış işler", text: $viewModel.customer.disIsler)
                  TextField("Sarf Malzeme", text: $viewModel.customer.sarf)
                  TextField("Toplam \(toplams)", text: $viewModel.customer.toplam)
                  let alinan = Int(viewModel.customer.alınan) ?? 0
                  TextField("Ödenen", text: $viewModel.customer.alınan)
                  let kalans = toplams - alinan
                  TextField("Kalan \(kalans)", text:$viewModel.customer.kalan)
             
              }
              Section(header: Text("Bakım Kaydı")){
                  Group{
                      TextField("Bir Sonraki Kilometre", text: $viewModel.customer.nextKm)
                      TextField("Yağ", text: $viewModel.customer.oil)
                      TextField("Hava Filtresi", text: $viewModel.customer.havaF)
                      TextField("Yağ Filtresi", text: $viewModel.customer.yagF)
                      TextField("Yakıt Filtresi", text: $viewModel.customer.yakıtF)
                  }
                  Group{
                      TextField("Polen Filtresi", text: $viewModel.customer.polenF)
                      TextField("Antifiriz", text: $viewModel.customer.antifriz)
                      TextField("Fren Balatası", text: $viewModel.customer.fren)
                      TextField("Debriyaj Seti", text: $viewModel.customer.debriyaj)
                      TextField("V Kayışı", text: $viewModel.customer.vKayiş)
                      TextField("Triger Seti", text: $viewModel.customer.triger)
                      TextField("Buji", text: $viewModel.customer.buji)
                      TextField("Not: ", text:$viewModel.customer.nots)
                  }
              }
              /*Section(header: Text("Resim")){

                  VStack {
                      
                      if imageURL != "" {
                          FirebaseImageView(imageURL: imageURL)

                      }
                      
                      Button(action: { self.shown.toggle() }) {
                          HStack{
                              Spacer()
                              Image(systemName: "photo")
                                  .font(.system(size: 100))
                              Spacer()
                          }
                        
                          
                      }.sheet(isPresented: $shown) {
                          imagePicker(shown: self.$shown,imageURL: self.$imageURL)
                         
                          }.padding(10)
                      Spacer()
                      

                      

                      
                  }
                      
                  }*/

            
  
              if mode == .edit {
                  Section {
                      Button("Kaydı Sil") { self.presentActionSheet.toggle() }
                          .foregroundColor(.red)
                  }
              }
          }
         
          .navigationTitle(mode == .new ? "Yeni Müşteri" : viewModel.customer.name)
          .navigationBarTitleDisplayMode(mode == .new ? .inline : .large)
          .navigationBarItems(
            leading: cancelButton,
            trailing: saveButton
          )
          .actionSheet(isPresented: $presentActionSheet) {
              ActionSheet(title: Text("Kayıt silinsin mi?"),
                          buttons: [
                            .destructive(Text("Evet"),
                                         action: { self.handleDeleteTapped() }),
                            .cancel()
                          ])
          }

      }
    }

      
  }

   
  func handleCancelTapped() {
    self.dismiss()
     
  }
    
   
  func handleDoneTapped() {
     
          let storage = Storage.storage().reference(withPath: imageURL)
          storage.downloadURL { (url, error) in
              if error != nil {
                  //print((error?.localizedDescription)!)
                  return
              }
              //print(url!)
              self.imageURL = "\(url!)"
              //print("Yükleme adresiniz \(url!)")
              storage.downloadURL { url, error in
                  print("Yükleme adresiniz \(imageURL)")
                                
              }
          }
    self.viewModel.handleDoneTapped()
    self.dismiss()
  }
   
  func handleDeleteTapped() {
    viewModel.handleDeleteTapped()
    self.dismiss()
    self.completionHandler?(.success(.delete))
  }
   
  func dismiss() {
      
    self.presentationMode.wrappedValue.dismiss()
      
  }

}
 

struct CustomerEditView_Previews: PreviewProvider {
  static var previews: some View {
    
      let customer = Customer(name: "", telefon: "", marka: "", plaka: "", şase: "", sikayet: "", km: "", islem: "", isyeri: "", not: "", resim: "", yedekp: "" , iscilik: "", yag: "", disIsler: "", toplam: "" , alınan: "", kalan:"" , tarih: "", nextKm:"" , oil: "",
                              havaF: "", yagF:"", yakıtF: "", polenF: "", antifriz: "", fren: "", debriyaj: "",vKayiş: "",triger: "",buji: "", nots: "", sifre: "", sarf: "", resim2: "", resim3: "", resim4: "", resim5: "")
    let customerViewModel = CustomerViewModel(customer: customer)
    return CustomerEditView(viewModel: customerViewModel, mode: .edit)
  }
}
