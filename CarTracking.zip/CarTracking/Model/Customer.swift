//
//  Customer.swift
//  CarTracking
//
//  Created by Ali Osman GÖK on 6.09.2023.
//

import SwiftUI
import Foundation
import FirebaseFirestoreSwift
 
struct Customer: Identifiable, Codable {

 
  @DocumentID var id: String?
    var name : String
    var telefon : String
    var marka: String
    var plaka : String
    var şase: String
    var sikayet: String
    var km: String
    var islem : String
    var isyeri : String
    var not : String
    var resim : String
    var yedekp : String
    var iscilik : String
    var yag : String
    var disIsler : String
    var toplam : String
    var alınan : String
    var kalan : String
    var tarih : String
    var nextKm : String
    var oil : String
    var havaF : String
    var yagF : String
    var yakıtF : String
    var polenF : String
    var antifriz : String
    var fren : String
    var debriyaj : String
    var vKayiş : String
    var triger : String
    var buji : String
    var nots: String
    var sifre: String
    var sarf : String
    var resim2 : String
    var resim3 : String
    var resim4 : String
    var resim5 : String
   
    
 
  enum CodingKeys: String, CodingKey {
      case id
      case name
      case telefon
      case marka
      case plaka
      case sikayet
      case şase
      case km
      case islem
      case isyeri
      case not
      case resim
      case yedekp
      case iscilik
      case yag
      case disIsler
      case toplam
      case alınan
      case kalan
      case tarih
      case nextKm
      case oil
      case havaF
      case yagF
      case yakıtF
      case polenF
      case antifriz
      case fren
      case debriyaj
      case vKayiş
      case triger
      case buji
      case nots
      case sifre
      case sarf
      case resim2
      case resim3
      case resim4
      case resim5
      
  }
}

