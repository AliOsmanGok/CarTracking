//
//  LoginView.swift
//  CarTracking
//
//  Created by Ali Osman GÖK on 6.09.2023.
//

import SwiftUI
import Firebase
import FirebaseStorage
import FirebaseAuth
import FirebaseDatabase
import FirebaseFirestore

class firebaseManager: NSObject{
    let auth : Auth
    static let shared = firebaseManager()
    
    override init(){
       
        
        self.auth = Auth.auth()
        super.init()
    }
}


struct LoginView: View {
    @State var mail = ""
    @State var sifre = ""
    @EnvironmentObject var settings: UserSettings
    
    var body: some View {
        if settings.isLoggedIn{
            ContentView()
                .environmentObject(settings)
        }else{
            if UserDefaults.standard.bool(forKey: "login") == true{
                ContentView().environmentObject(settings)
            }
            else{
                
                NavigationView{
                    
                    VStack{
                        Image("logo")
                            .resizable()
                            .frame(width: UIScreen.main.bounds.width * 0.85, height: UIScreen.main.bounds.height * 0.25)
                            .cornerRadius(10)
                            .overlay(RoundedRectangle(cornerRadius: 10)
                                .stroke(Color.black, lineWidth: 5))
                            .shadow(radius: 10)
                            .padding()

                        TextField(" Mail", text: $mail)
                            .padding()
                            .background(Color.black.opacity(0.1))
                            .cornerRadius(15)
                            .padding()
                        SecureField(" Şifre", text: $sifre)
                            .keyboardType(.numberPad)
                            .padding()
                            .background(Color.black.opacity(0.1))
                            .cornerRadius(15)
                            .padding()
                        Button("Giriş Yap"){
                            firebaseManager.shared.auth.signIn(withEmail: mail, password: sifre){ result, error in
                                if error == nil{
                                    print("Giriş başarılı")
                                    settings.isLoggedIn = true
                                    
                                }else{
                                    print("Giriş yapılamadı")
                                }
                            }
                        }
                            .foregroundStyle(.white)
                            .padding()
                            .background(.blue)
                            .clipShape(Capsule())
                    }
                    
                }
            }
        }
    }
}

struct LoginView_Previews: PreviewProvider {
    static var previews: some View {
        LoginView()
            .environmentObject(UserSettings())
    }
}
