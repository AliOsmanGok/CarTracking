//
//  CustomerViewModel.swift
//  CarTracking
//
//  Created by Ali Osman GÖK on 6.09.2023.
//

import Foundation
import Combine
import FirebaseFirestore
import SDWebImageSwiftUI
import FirebaseStorage




class CustomerViewModel: ObservableObject {

   
  @Published var customer: Customer
  @Published var modified = false

  private var cancellables = Set<AnyCancellable>()

    init(customer: Customer = Customer(name: "", telefon: "", marka: "", plaka: "", şase: "", sikayet: "", km: "", islem: "", isyeri: "", not: "", resim: "\(resims)", yedekp: "", iscilik: "", yag: "", disIsler: "", toplam: "", alınan: "", kalan:"" , tarih: "", nextKm:"" , oil: "",
                                       havaF: "", yagF:"", yakıtF: "", polenF: "", antifriz: "", fren: "", debriyaj: "",vKayiş: "",triger: "",buji: "", nots: "", sifre: "",
                                        sarf: "", resim2: "", resim3: "", resim4: "", resim5: "") ) {
    self.customer = customer
     
    self.$customer
      .dropFirst()
      .sink { [weak self] customer in
        self?.modified = true
      }
      .store(in: &self.cancellables)
  }
   
  private var db = Firestore.firestore()
   
  private func addCustomer(_ customer: Customer) {
    do {
        let _ = try db.collection("customers").addDocument(from: customer)
    }
    catch {
      print(error)
    }
  }
   
  private func updateCustomer(_ customer: Customer) {
    if let documentId = customer.id {
      do {
        try db.collection("customers").document(documentId).setData(from: customer)
          
      }
      catch {
        print(error)
      }
    }
  }
   
  private func updateOrAddCustomer() {
    if let _ = customer.id {
      self.updateCustomer(self.customer)
    }
    else {
      addCustomer(customer)
    }
  }
    private func UploadPhoto(){
        
    }
   
  private func removeCustomer() {
    if let documentId = customer.id {
      db.collection("customers").document(documentId).delete { error in
        if let error = error {
          print(error.localizedDescription)
        }
      }
    }
  }
   
  func handleDoneTapped() {
    self.updateOrAddCustomer()
  }
   
  func handleDeleteTapped() {
    self.removeCustomer()
  }
   
}


