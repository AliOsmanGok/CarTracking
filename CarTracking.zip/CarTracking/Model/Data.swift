//
//  Data.swift
//  CarTracking
//
//  Created by Ali Osman GÖK on 6.09.2023.
//

import SwiftUI
import Firebase
 
class getData : ObservableObject{
     
    @Published var datas = [dataType]()
     
    init() {
         
        let db = Firestore.firestore()
         
        db.collection("customers").getDocuments { (snap, err) in
             
            if err != nil{
                 
                print((err?.localizedDescription)!)
                return
            }
             
            for i in snap!.documents{
                 
                let id = i.documentID
                let name = i.get("name") as! String
                let sifre = i.get("sifre") as! String
                 
                self.datas.append(dataType(id: id, name: name, sifre: sifre))
            }
        }
    }
}
 
struct dataType : Identifiable {
     
    var id : String
    var name : String
    var sifre : String
}


