//
//  ImagePickerController.swift
//  CarTracking
//
//  Created by Ali Osman GÖK on 6.09.2023.
//

import SwiftUI
import FirebaseStorage
import Combine


struct imagePicker: UIViewControllerRepresentable {



    @Binding var shown: Bool
    @Binding var imageURL:String
    
    func makeCoordinator() -> imagePicker.Coordinator {
        return imagePicker.Coordinator(parent: self)
    }
    
    class Coordinator: NSObject,UIImagePickerControllerDelegate,UINavigationControllerDelegate {
        var parent: imagePicker
        let storage = Storage.storage().reference()
        init(parent: imagePicker) {
            self.parent = parent
        }
        
        func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
            parent.shown.toggle()
        }
        
        func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
            let image = info[.originalImage] as! UIImage
            uploadImageToFireBase(image: image)
        }
        
        func uploadImageToFireBase(image: UIImage) {
       
            
            let metadata = StorageMetadata()
            metadata.contentType = "image/jpeg"
          

            storage.child(resimad).putData(image.jpegData(compressionQuality: 0.42)!, metadata: metadata) { (metadata, error) in
                guard let metadata = metadata else {
          
                  print((error?.localizedDescription)!)
                  return
                }
     
                let size = metadata.size
                
                print("Upload size is \(size)")
                print("Upload success")
                self.downloadImageFromFirebase()
            }
        }
        
        func downloadImageFromFirebase() {
    
           
            storage.child(resimad).downloadURL { (url, error) in
                if error != nil {
                
                    print((error?.localizedDescription)!)
                    return
                }
                print("Download success")
                self.parent.imageURL = "\(url!)"
                self.parent.shown.toggle()
                
                self.listOfImageFile()
            }
        }
        
        func listOfImageFile() {
            let storageReference = Storage.storage().reference()//.child("images/")
            storageReference.listAll { (result, error) in
              if error != nil {
            
                  print((error?.localizedDescription)!)
                  return
              }
                for prefix in result!.prefixes {

                print("prefix is \(prefix)")
              }
                for item in result!.items {
 
                print("items is \(item)")
              }
            }
        }
    }
    
    func makeUIViewController(context: UIViewControllerRepresentableContext<imagePicker>) -> UIImagePickerController {
        let imagepic = UIImagePickerController()
        imagepic.sourceType = .photoLibrary
        imagepic.delegate = context.coordinator
        return imagepic
    }
    
    func updateUIViewController(_ uiViewController: UIImagePickerController, context: UIViewControllerRepresentableContext<imagePicker>) {
    }
}


